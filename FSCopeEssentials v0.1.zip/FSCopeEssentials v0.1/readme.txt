FSCope Essentials v0.1
This app can be started by running run.bat

It analyzes the csv files in the spreadsheets folder, structures it into the file objects/clients.json,
and then analyzes it for errors.

These data quality issues are output in human-readable form in the file error.txt.


